ORG 100h

START:
    MOV AX, [SAYI]      ; Kontrol edilecek sayiyi AX'e al
    
    CALL ASAL_MI        ; Alt programi cagir
    
    MOV [SONUC], AL     ; Sonucu SONUC degiskenine kaydet
    
    ; Programi sonlandir
    MOV AH, 4Ch         
    INT 21h             


ASAL_MI PROC
    ; 0, 1 ve 2 icin ozel durumlar
    CMP AX, 2           ; Sayi 2'ye esit mi
    JE ASAL_BULUNDU     ; 2 asaldir, ASAL_BULUNDU'ya atla
    
    CMP AX, 2           ; Sayi 2'den kucuk mu?
    JB ASAL_DEGIL       ; 0 ve 1 asal degildir
    
    MOV BX, 2           ; Bolen = 2 (ilk asal)
    MOV [KONTROL_SAYI], AX  ; Kontrol edilecek sayiyi sakla
    
BOLME_DONGUSU:                                     

    MOV AX, [KONTROL_SAYI]
    CMP BX, AX          ; Bolen >= sayi mi
    JAE ASAL_BULUNDU    ; Evet ise sayi asaldir
    
    ; Bolme islemi AX = sayi, BX = bolen
    MOV AX, [KONTROL_SAYI]
    MOV DX, 0           ; DX'i temizle 
    DIV BX              ; AX / BX, AX=bolum, DX=kalan
                                 
                                 
    CMP DX, 0           ; Kalan = 0 mi
    JE ASAL_DEGIL       ; Evet ise tam bolunur, asal degil
                              

    INC BX              ; Boleni 1 artir
    JMP BOLME_DONGUSU   ; Donguye devam et
    
ASAL_BULUNDU:
    MOV AL, 1           ; Asal ise AL = 1
    RET                 ; Alt programdan cik
    
ASAL_DEGIL:
    MOV AL, 0           ; Asal degilse AL = 0
    RET                 ; Alt programdan cik
    
ASAL_MI ENDP

; Veri alani
SAYI DW 13              ; Kontrol edilecek sayi
KONTROL_SAYI DW 0       ; Gecici saklama alani
SONUC DB 0              ; Sonuc 1=asal, 0=asal degil (0713E adresine denk geliyor - AL'den de bakilabilir)

END START