ORG 100h

START:
    ; SI register'ini sayilar dizisinin baslangic adresine ayarla
    LEA SI, SAYILAR     ;0700:0109 adresinden bakilabilir (07123'e geliyor en kucuk)
    
    MOV AL, [SI]        ; Ilk sayiyi AL register'ina yukle
    MOV BL, AL          ; BL'ye kopyala (en kucuk degeri tutcak)
    
    MOV CX, 4           ; CX, karsilastirma sayisi
    INC SI              ; SI'yi bir sonraki sayiya ilerlet
    
KARSILASTIR:
    MOV AL, [SI]        ; Siradaki sayiyi AL'ye al
    
    CMP AL, BL          ; AL ile BL'yi karsilastir
    JAE DEVAM           ; AL >= BL ise DEVAM'a gec (degistirme yok)
    
    ; Eger AL < BL ise
    MOV BL, AL          ; BL'yi guncelle (yeni en kucuk)
    
DEVAM:
    INC SI              ; Bir sonraki sayiya gec
    LOOP KARSILASTIR    ; CX'i azalt ve 0 degilse donguye devam
    
    MOV [EN_KUCUK], BL  ; BL'deki en kucuk degeri EN_KUCUK adresine kaydet
    
    ; Programi sonlandir
    MOV AH, 4Ch         
    INT 21h             

; Veri alani
SAYILAR DB 45, 15, 78, 93, 56    
EN_KUCUK DB 0                     ; En kucuk degerin saklanacagi yer(Ayrica BL'den de bakilabilir)

END START