ORG 100h

START:
    MOV CX, 4           ; Dis dongu - n-1 gecis yapilacak
    
DIS_DONGU:
    PUSH CX             ; Dis dongu sayacini sakla
    
    ; Ic dongu icin hazirlik
    LEA SI, ASALLAR     ; SI'yi dizinin basina ayarla
    MOV CX, 4           ; Ic dongu sayaci
    
IC_DONGU:
    MOV AL, [SI]        ; Ilk elemani AL'ye yukle
    MOV BL, [SI+1]      ; Ikinci elemani BL'ye yukle
    
    CMP AL, BL          ; AL ile BL'yi karsilastir
    JBE DEGISTIRME_YOK  ; AL <= BL ise degistirme yapma
    
    ; Swap islemi
    MOV [SI], BL        ; Ikinci elemani ilk pozisyona yaz
    MOV [SI+1], AL      ; Ilk elemani ikinci pozisyona yaz
    
DEGISTIRME_YOK:
    INC SI              ; Bir sonraki elemana gec
    LOOP IC_DONGU       ; Ic donguyu devam ettir
    
    POP CX              ; Dis dongu sayacini geri yukle
    LOOP DIS_DONGU      ; Dis donguyu devam ettir
    
    ; Programi sonlandirma
    MOV AH, 4Ch         
    INT 21h             

; Veri alani 
ASALLAR DB 29, 13, 2, 19, 3     ; asal sayilarim (0700:0109 adresinde gorunuyor)

END START